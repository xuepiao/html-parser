#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QNetworkAccessManager>
#include <QWebElement>
#include <QLineEdit>



namespace Ui {
    class MainWindow;
}


class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

public slots:
    void query(QNetworkReply* reply);

protected slots:

    void changeLocation();     // �ı�·��


private:
    Ui::MainWindow *ui;

    QNetworkAccessManager* mgr;

    QString *content;       //д���ı��༭��1

    QString *content2;      //д���ı��༭��2

    QLineEdit *addrEdit;

    bool flag;


};

#endif // MAINWINDOW_H
